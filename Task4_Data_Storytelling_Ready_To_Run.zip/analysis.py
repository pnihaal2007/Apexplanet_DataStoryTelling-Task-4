import pandas as pd
from scipy import stats
import numpy as np
import matplotlib.pyplot as plt

FILE = "sales_dataset.xlsx"
df = pd.read_excel(FILE)

# Basic validation
calc = df["Quantity"] * df["Unit_Price"]
print("Rows with Sales mismatch:", (~np.isclose(calc, df["Total_Sales"], rtol=1e-6, atol=0.02)).sum())

# KPIs
revenue = df["Total_Sales"].sum()
orders = df["Order_ID"].nunique()
aov = revenue / orders
customer_counts = df.groupby("Customer_ID").size()
repeat_rate = (customer_counts.gt(1).sum() / customer_counts.size) * 100
print(f"Total Revenue: ₹{revenue:,.2f}")
print(f"Distinct Orders: {orders:,}")
print(f"AOV: ₹{aov:,.2f}")
print(f"Repeat-Customer Rate: {repeat_rate:.2f}%")

print("\nRevenue by Category")
print(df.groupby("Category")["Total_Sales"].sum().sort_values(ascending=False))
print("\nRevenue by City")
print(df.groupby("City")["Total_Sales"].sum().sort_values(ascending=False))

# Monthly trend
df["Order_Date"] = pd.to_datetime(df["Order_Date"])
monthly = df.groupby(df["Order_Date"].dt.to_period("M"))["Total_Sales"].sum()
monthly.plot(marker="o", title="Monthly Revenue")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("monthly_revenue_output.png", dpi=160)
plt.close()

# Hypothesis: Electronics vs non-Electronics order value
x = df.loc[df["Category"].eq("Electronics"), "Total_Sales"].dropna()
y = df.loc[~df["Category"].eq("Electronics"), "Total_Sales"].dropna()
t, p = stats.ttest_ind(x, y, equal_var=False)

# Welch confidence interval
v1, v2 = x.var(ddof=1), y.var(ddof=1)
se = np.sqrt(v1/len(x) + v2/len(y))
df_w = (v1/len(x) + v2/len(y))**2 / ((v1/len(x))**2/(len(x)-1) + (v2/len(y))**2/(len(y)-1))
crit = stats.t.ppf(0.975, df_w)
diff = x.mean() - y.mean()
ci = (diff - crit*se, diff + crit*se)

print("\nWelch T-Test: Electronics vs Non-Electronics")
print(f"Electronics mean: ₹{x.mean():,.2f}")
print(f"Non-Electronics mean: ₹{y.mean():,.2f}")
print(f"t-statistic: {t:.4f}")
print(f"p-value: {p:.4f}")
print(f"95% CI of difference: ₹{ci[0]:,.2f} to ₹{ci[1]:,.2f}")
print("Conclusion:", "Statistically significant" if p < 0.05 else "Not statistically significant")
