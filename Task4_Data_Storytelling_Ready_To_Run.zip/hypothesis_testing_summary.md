# Hypothesis Testing Summary

## Business Question
Is the average order value for Electronics significantly different from all non-Electronics categories?

## Hypotheses
- **H0:** μ(Electronics) = μ(Non-Electronics)
- **H1:** μ(Electronics) ≠ μ(Non-Electronics)

## Method
Welch's independent two-sample t-test was used because it does not require equal population variances. Significance level α = 0.05.

## Results
- Electronics observations: 354
- Non-Electronics observations: 646
- Electronics mean: ₹143,442.32
- Non-Electronics mean: ₹137,183.99
- Difference: ₹6,258.33
- t-statistic: 0.8179
- p-value: 0.4137
- 95% CI for mean difference: ₹-8,764.16 to ₹21,280.82

## Interpretation
Because p > 0.05 and the 95% confidence interval includes zero, we fail to reject H0. The dataset does not provide sufficient evidence that Electronics has a different average order value from other categories.

## Business Conclusion
Electronics clearly leads total revenue, but this test does not support the claim that its average order value is inherently higher. Treat category revenue leadership and per-order value as separate findings.
