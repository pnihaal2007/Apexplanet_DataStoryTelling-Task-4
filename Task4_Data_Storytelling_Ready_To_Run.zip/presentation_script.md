# 7–10 Minute Stakeholder Presentation Script

## Slide 1 — Opening
This analysis turns the sales dataset into a business story and validates one key assumption statistically. The focus is on revenue concentration, customer retention, monthly performance, and a test of Electronics order value.

## Slide 2 — Executive Snapshot
The dataset generates about ₹139.4 million in revenue across 992 distinct orders. Average order value is roughly ₹140,524. The most important warning sign is repeat purchasing: only about 5.5% of unique customers appear more than once.

## Slide 3 — Category Story
Electronics is the strongest category with about ₹50.8 million in revenue. Laptop and Mobile are the two biggest products. This makes Electronics commercially important, but total revenue alone cannot tell us whether an individual Electronics order is actually larger.

## Slide 4 — Time Trend
Revenue varies across months, with the strongest month in 2025-03. This suggests inventory and campaign timing should follow observed demand patterns. Because this dataset covers a limited period, future months should be used to confirm whether the seasonality repeats.

## Slide 5 — Retention
The strongest growth opportunity is retention. There are 947 unique customers, but only 52 repeat customers. The business should introduce post-purchase communication, loyalty incentives, and cohort tracking to improve customer lifetime value.

## Slide 6 — Hypothesis
I tested whether Electronics has a different average order value from non-Electronics categories. I used Welch's two-sample t-test, which is suitable when the two groups may have different variances.

## Slide 7 — Result
Electronics averages about ₹143,442 per observation compared with ₹137,184 for other categories. However, the p-value is 0.4137, which is greater than 0.05, and the 95% confidence interval includes zero. So the difference is not statistically significant.

## Slide 8 — Actions
The recommendations are to improve repeat purchasing, protect high-revenue Electronics inventory, plan around monthly demand, localize campaigns in top cities, and keep validating important business claims statistically.

## Slide 9 — Close
The final story is simple: revenue is strong and Electronics leads, but loyalty is weak. The biggest opportunity is to convert one-time buyers into repeat customers while using statistical validation to avoid overclaiming what the data proves.
